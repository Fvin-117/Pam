import {Image, Pressable, StyleSheet, Text, View, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function TelaInicial() {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Tela Inicial</Text>
      <Pressable style={styles.Retornar}
        onPress={() => {
          navigation.navigate('Site');
        }}>
        <Image style={styles.poke}source={require('../assets/botao-play.png')}/>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  Retornar: {
    justifyContent: "center"
  },
  poke: {
    width: 55,
    height: 55,
    
  },
});
