import { createDrawerNavigator } from '@react-navigation/drawer';
import BottomTabs from "./BottomTabs"
import Perfil from "./Perfil"
import Deck from './Decks'
import Home from './Homescreen';
import Settings from './Settings'

const Drawer = createDrawerNavigator();

export default function DrawerNav() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#1a7a2e',
        },
        headerTintColor: '#f0c000',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        drawerStyle: {
          backgroundColor: '#1a7a2e',
        },
        drawerLabelStyle: {
          color: '#f0c000',
          fontWeight: 'bold',
          fontSize: 15,
        },
        drawerActiveTintColor: '#f0c000',
        drawerInactiveTintColor: '#a8d5b5',
        drawerActiveBackgroundColor: '#145e23',
      }}
    >
      <Drawer.Screen name="Home" component={Home} />
      <Drawer.Screen name="Copas" component={Deck} />
      <Drawer.Screen name="Contatos" component={Settings} />
      <Drawer.Screen name="Form" component={Perfil} />
    </Drawer.Navigator>
  )
}