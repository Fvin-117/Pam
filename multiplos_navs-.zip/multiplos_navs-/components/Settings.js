import React, { useState } from 'react';

import {
  Image,
  StyleSheet,
  Text,
  View,
  Pressable,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';

import { useNavigation } from '@react-navigation/native';

const assets = {
  retorno: require('../assets/retorno.png'),
};

export default function Contato() {
  const navigation = useNavigation();

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [mensagem, setMensagem] = useState('');

  const handleEnviar = () => {
    if (!nome || !email || !mensagem) {
      Alert.alert('Atenção', 'Por favor, preencha todos os campos.');
      return;
    }

    Alert.alert('Sucesso', 'Mensagem enviada com sucesso!');
    setNome('');
    setEmail('');
    setMensagem('');
  };

  return (
    <View style={styles.container}>

      {/* Header */}
      <View style={styles.header}>

        <Pressable
          style={styles.Retornar}
          onPress={() => {
            navigation.navigate('telainicial');
          }}
        >
          <Image
            style={styles.poke}
            source={assets.retorno}
          />
        </Pressable>

        <Text style={styles.headerTitle}>
          Contato
        </Text>

      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>

  

        {/* Card de informações */}
        <View style={styles.infoCard}>

          <Text style={styles.infoTitle}>
            Outras formas de contato
          </Text>

          <Text style={styles.infoText}>
            📧 Flavio Lacerda
            </Text>
          <Text style={styles.infoText}>
            📧 Fellipe Rafael
          </Text>

          <Text style={styles.infoText}>
            📞 (15) 99999-9999
          </Text>
          <Text style={styles.infoText}>
            📞 929-556-2746
          </Text>

          <Text style={styles.infoText}>
            📍 Sorocaba, Brasil
          </Text>

        </View>

      </ScrollView>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009c3b',
  },

  header: {
    backgroundColor: '#006633',
    height: 50,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',

    paddingHorizontal: 15,
  },

  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffdf00',
  },

  Retornar: {
    position: 'absolute',
    left: 15,
  },

  poke: {
    width: 25,
    height: 25,
  },

  scrollContent: {
    padding: 20,
  },

  contactCard: {
    backgroundColor: '#ffdf00',

    borderRadius: 20,
    padding: 20,

    borderWidth: 3,
    borderColor: '#002776',

    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,

    marginBottom: 20,
  },

  sectionTitle: {
    color: '#002776',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  label: {
    color: '#002776',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 6,
  },

  input: {
    backgroundColor: 'white',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#002776',

    paddingHorizontal: 12,
    paddingVertical: 10,

    color: '#1a1a1a',
    fontSize: 15,

    marginBottom: 16,
  },

  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },

  botaoEnviar: {
    backgroundColor: '#002776',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
  },

  botaoEnviarTexto: {
    color: '#ffdf00',
    fontSize: 16,
    fontWeight: 'bold',
  },

  infoCard: {
    backgroundColor: '#006633',
    borderRadius: 20,
    padding: 20,

    borderWidth: 2,
    borderColor: '#ffdf00',
  },

  infoTitle: {
    color: '#ffdf00',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },

  infoText: {
    color: 'white',
    fontSize: 15,
    marginBottom: 8,
  },
});