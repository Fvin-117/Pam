import React, { useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import DeckCard from './DeckCard'

import {
  FlatList,
  StyleSheet,
  Text,
  View,
  Pressable,
  Image
} from 'react-native';

const DATA = [
  {
    id: '1',
    title: '🏆 Copa de 1958 — Suécia',
    description:
      'Primeiro título mundial do Brasil. Pelé, com apenas 17 anos, marcou 2 gols na final. Vitória por 5x2 sobre a Suécia.',
    color: '#1a7a2e',
  },
  {
    id: '2',
    title: '🏆 Copa de 1962 — Chile',
    description:
      'Bicampeonato com Garrincha brilhando após Pelé se machucar. Final contra a Tchecoslováquia: 3x1.',
    color: '#2a8f3f',
  },
  {
    id: '3',
    title: '🏆 Copa de 1970 — México',
    description:
      'Considerada a maior seleção de todos os tempos. Pelé, Tostão, Rivelino e Jairzinho. Final: 4x1 sobre a Itália. Brasil ficou com a Taça Jules Rimet definitivamente.',
    color: '#f0c000',
  },
  {
    id: '4',
    title: '🏆 Copa de 1994 — EUA',
    description:
      'Tetracampeonato após 24 anos de jejum. Romário e Bebeto formaram a dupla histórica. Final contra a Itália decidida nos pênaltis: 3x2.',
    color: '#1a7a2e',
  },
  {
    id: '5',
    title: '🏆 Copa de 2002 — Japão/Coreia',
    description:
      'Pentacampeonato com Ronaldo Fenômeno artilheiro, marcando 8 gols. Final: 2x0 sobre a Alemanha. O maior número de títulos mundiais da história.',
    color: '#2a8f3f',
  },
];

export default function Deck() {
  const navigation = useNavigation()
  return (
    <View style={styles.container}>

      <View style={styles.topBar}>
        <Pressable
          style={styles.Retornar}
          onPress={() => {
            navigation.navigate('telainicial');
          }}>
          <Image style={styles.poke} source={require('../assets/retorno.png')} />
        </Pressable>
        <Text style={styles.pageTitle}>
          🇧🇷 Copas do Mundo
        </Text>
      </View>

      <FlatList
        data={DATA}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{
          padding: 15,
        }}
        renderItem={({ item }) => (
          <DeckCard title={item.title} description={item.description} color={item.color}/>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f0d0',
  },

  topBar: {
    height: 50,
    backgroundColor: '#1a7a2e',
    justifyContent: 'center',
    alignItems: 'center',
  },

  pageTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#f0c000',
  },

  card: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 15,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },

  title: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    width: '75%',
  },

  description: {
    color: 'white',
    fontSize: 15,
    lineHeight: 22,
  },
  poke: {
    width: 25,
    height: 25,
  },
  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
});