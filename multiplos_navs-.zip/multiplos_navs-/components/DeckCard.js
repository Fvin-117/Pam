import {StyleSheet, View, Text} from 'react-native'

export default function DeckCard(props) {

  return (
    <View
      style={[
        styles.card,
        { backgroundColor: props.color },
      ]}
    >

      <View style={styles.header}>

        <Text style={styles.title}>
          {props.title}
        </Text>

      </View>

      <Text style={styles.description}>
        {props.description}
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },

  topBar: {
    height: 50,
    backgroundColor: '#d3d3d3',

    justifyContent: 'center',
    alignItems: 'center',
  },

  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#222',
  },

  card: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 15,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',

    marginBottom: 12,
  },

  title: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',

    width: '75%',
  },

  description: {
    color: 'white',
    fontSize: 15,
    lineHeight: 22,
  },
  poke: {
    width: 25,
    height: 25,
  },
  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
});