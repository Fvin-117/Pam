import {
  ScrollView,
  Image,
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
} from 'react-native';

import { useState } from 'react';
import { useNavigation } from '@react-navigation/native';

export default function Perfil() {
  const navigation = useNavigation();
  const [username, setUsername] = useState('');
  const [descricao, setDescricao] = useState('');
  const [email, setEmail] = useState('');
  const [dataNasc, setDataNasc] = useState('');

  function limparCampos() {
    setUsername('');
    setDescricao('');
    setEmail('');
    setDataNasc('');
  }

  return (
    <ScrollView style={styles.container}>

      {/* Header */}
      <View style={styles.header}>
        <Pressable
          style={styles.Retornar}
          onPress={() => navigation.navigate('telainicial')}
        >
          <Image source={require('../assets/retorno.png')} style={styles.poke} />
        </Pressable>
        <Text style={styles.headerTitle}>🇧🇷 Perfil</Text>
      </View>

      {/* Card Form */}
      <View style={styles.profileCard}>

        <Text style={styles.cardTitle}>Editar Perfil</Text>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Nome de usuário</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite seu usuário..."
            placeholderTextColor="#5a9e6f"
            value={username}
            onChangeText={setUsername}
          />
        </View>

        <View style={styles.inputBox}>
          <Text style={styles.label}>E-mail</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite seu e-mail..."
            placeholderTextColor="#5a9e6f"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
          />
        </View>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Data de nascimento</Text>
          <TextInput
            style={styles.input}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#5a9e6f"
            keyboardType="numeric"
            value={dataNasc}
            onChangeText={setDataNasc}
          />
        </View>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Descrição</Text>
          <TextInput
            style={[styles.input, styles.inputMultiline]}
            placeholder="Fale um pouco sobre você..."
            placeholderTextColor="#5a9e6f"
            multiline
            numberOfLines={4}
            value={descricao}
            onChangeText={setDescricao}
          />
        </View>

        <Pressable
          style={({ pressed }) => [styles.botao, pressed && styles.botaoPressed]}
          onPress={limparCampos}
        >
          <Text style={styles.botaoTexto}>✅ Enviar</Text>
        </Pressable>

      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f0d0',
  },

  header: {
    backgroundColor: '#1a7a2e',
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 15,
  },

  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#f0c000',
  },

  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  poke: {
    width: 25,
    height: 25,
    tintColor: '#f0c000',
  },

  profileCard: {
    margin: 20,
    backgroundColor: '#145e23',
    borderRadius: 25,
    padding: 25,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
    borderWidth: 2,
    borderColor: '#f0c000',
  },

  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#f0c000',
    marginBottom: 20,
    textAlign: 'center',
  },

  inputBox: {
    width: '100%',
    marginBottom: 16,
  },

  label: {
    color: '#f0c000',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
  },

  input: {
    backgroundColor: '#1a7a2e',
    color: 'white',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    borderWidth: 1.5,
    borderColor: '#f0c000',
  },

  inputMultiline: {
    height: 100,
    textAlignVertical: 'top',
  },

  botao: {
    marginTop: 10,
    backgroundColor: '#f0c000',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },

  botaoPressed: {
    backgroundColor: '#c9a000',
    transform: [{ scale: 0.97 }],
  },

  botaoTexto: {
    color: '#1a7a2e',
    fontSize: 16,
    fontWeight: 'bold',
  },
});