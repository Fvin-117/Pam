import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
  Pressable,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Comentario from './comentario';

const assets = {
  retorno: require('../assets/retorno.png'),
  vinijr: require('../assets/vini_jr.jpg'),
  rodrygo: require('../assets/rodrygo.jpg'),
  endrick: require('../assets/endrick.webp'),
  lucas: require('../assets/lucas.jpg'),
  raphinnha: require('../assets/raphinha.jpg'),
  alisson: require('../assets/alisson.jpg'),
};

const DATA = [
  {
    id: '1',
    username: 'Vini Jr.',
    comment: 'Atacante do Real Madrid e da Seleção Brasileira. Veloz, driblador e artilheiro. Um dos melhores jogadores do mundo atualmente.',
    image: assets.vinijr
  },
  {
    id: '2',
    username: 'Rodrygo',
    comment: 'Meia-atacante do Real Madrid. Decisivo em grandes jogos, conhecido pelos gols em momentos críticos na Champions League.',
    image: assets.rodrygo
  },
  {
    id: '3',
    username: 'Endrick',
    comment: 'Jovem atacante do Real Madrid. Revelação do Palmeiras, considerado uma das maiores promessas do futebol mundial.',
    image: assets.endrick
  },
  {
    id: '4',
    username: 'Lucas Paquetá',
    comment: 'Meia criativo do West Ham. Excelente na condução de bola e passes em profundidade, peça-chave na criação de jogadas.',
    image: assets.lucas
  },
  {
    id: '5',
    username: 'Raphinha',
    comment: 'Atacante do Barcelona. Ponta direita explosivo, capitão da Seleção Brasileira e referência ofensiva no time catalão.',
    image: assets.raphinnha
  },
  {
    id: '6',
    username: 'Alisson Becker',
    comment: 'Goleiro do Liverpool e da Seleção. Considerado um dos melhores goleiros do mundo, conhecido pela segurança e pelos pés.',
    image: assets.alisson
  },
];

export default function HomeScreen() {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable
          style={styles.Retornar}
          onPress={() => navigation.navigate('telainicial')}
        >
          <Image style={styles.poke} source={assets.retorno} />
        </Pressable>
        <Text style={styles.paragraph}>🇧🇷 Figurinhas</Text>
      </View>
      <View style={styles.container1}>
        <FlatList
          data={DATA}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 10 }}
          renderItem={({ item }) => (
            <Comentario
              username={item.username}
              comentario={item.comment}
              image={item.image}
            />
          )}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f0d0',
  },
  container1: {
    flex: 1,
    backgroundColor: '#f5f0d0',
  },
  header: {
    backgroundColor: '#1a7a2e',
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 15,
  },
  paragraph: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#f0c000',
  },
  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  poke: {
    width: 25,
    height: 25,
    tintColor: '#f0c000',
  },
});