import {
  Text,
  Image,
  View,
  StyleSheet,
} from 'react-native';

export default function Comentario(props) {
  return (
    <View style={styles.card}>

      {/* Figurinha */}
      <View style={styles.figurinha}>

        <View style={styles.figurinhaTop}>
          <Text style={styles.figurinhaPais}>🇧🇷 BRASIL</Text>
        </View>

        <View style={styles.imageWrapper}>
          <Image
            style={styles.playerImage}
            source={props.image}
            resizeMode="cover"
          />
        </View>

        <View style={styles.figurinhaBottom}>
          <Text style={styles.figurinhaName} numberOfLines={1}>
            {props.username}
          </Text>
          <Text style={styles.figurinhaNum}>★</Text>
        </View>

      </View>

      {/* Texto lateral */}
      <View style={styles.info}>
        <Text style={styles.username}>{props.username}</Text>
        <Text style={styles.comment}>{props.comentario}</Text>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#145e23',
    borderRadius: 15,
    padding: 14,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-start',
    borderWidth: 1.5,
    borderColor: '#f0c000',
    gap: 12,
  },

  /* ---- Figurinha ---- */
  figurinha: {
    width: 90,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#f0c000',
    backgroundColor: '#0e4a1a',
    flexShrink: 0,
  },

  figurinhaTop: {
    backgroundColor: '#f0c000',
    paddingVertical: 4,
    alignItems: 'center',
  },

  figurinhaPais: {
    fontSize: 9,
    fontWeight: 'bold',
    color: '#1a7a2e',
    letterSpacing: 1,
  },

  imageWrapper: {
    width: '100%',
    aspectRatio: 3 / 4,
    backgroundColor: '#1a7a2e',
  },

  playerImage: {
    width: '100%',
    height: '100%',
  },

  figurinhaBottom: {
    backgroundColor: '#f0c000',
    paddingVertical: 5,
    paddingHorizontal: 6,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  figurinhaName: {
    fontSize: 8,
    fontWeight: 'bold',
    color: '#1a7a2e',
    flexShrink: 1,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },

  figurinhaNum: {
    fontSize: 10,
    color: '#1a7a2e',
    fontWeight: 'bold',
  },

  /* ---- Texto lateral ---- */
  info: {
    flex: 1,
    justifyContent: 'flex-start',
  },

  username: {
    color: '#f0c000',
    fontWeight: 'bold',
    fontSize: 15,
    marginBottom: 6,
  },

  comment: {
    color: '#e8f5e9',
    fontSize: 13,
    lineHeight: 19,
  },
});