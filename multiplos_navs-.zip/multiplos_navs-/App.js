import { StyleSheet, Text, View, Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';

import TelaInicial from './components/TelaInicial';
import DrawerNav from './components/DrawerNav';
import BottomTabs from './components/BottomTabs'

const Stack = createStackNavigator();


export default function App() {
  return (
    
     <NavigationContainer>
       <Stack.Navigator>
         <Stack.Screen
           name="telainicial"
           component={TelaInicial}
           options={{ headerShown: false }}
         />
         <Stack.Screen name="Site" component={DrawerNav} options={{ headerShown: false }}/>
       </Stack.Navigator>
     </NavigationContainer>
  );
}
// function HomeScreen() {
//   const navigation = useNavigation();
//   return (
//     <View style={styles.container}>
//       <Button
//         title="<"
//         onPress={() => {
//           navigation.navigate('telainicial');
//         }}
//       />
//       <Text style={styles.paragraph}>HomeScreen</Text>
//     </View>
//   );
// }

// function TelaInicial()
// {
//   const navigation = useNavigation()
//   return(
//     <View>
//     <Button onPress={() => {
//             navigation.navigate('Site');
//           }} title = "App"></Button>
//     </View>
//   )
// }

// function BottomTabs() {
//   return (
//     <Tab.Navigator>
//       <Tab.Screen
//         name="Home"
//         component={HomeScreen}
//         options={{ headerShown: false }}
//       />
//       <Tab.Screen
//         name="Settings"
//         component={HomeScreen}
//         options={{ headerShown: false }}
//       />
//     </Tab.Navigator>
//   );
// }

// function Perfil() {
//   const navigation = useNavigation();
//   return (
//     <View>
//     <Button
//         title="<"
//         onPress={() => {
//           navigation.navigate('telainicial');
//         }}
//       />
//     <Text>Perfil</Text>;
//     </View>
//   )
// }

// import { createDrawerNavigator } from '@react-navigation/drawer';
// const Drawer = createDrawerNavigator();
// function DrawerNav() {
//   return (
//     <Drawer.Navigator>
//       <Drawer.Screen name="Home" component={BottomTabs} />
//       <Drawer.Screen name="Perfil" component={Perfil} />
//     </Drawer.Navigator>
//   );
// }

// function StackNav() {
//   return (
//     <Stack.Navigator>
//       <Stack.Screen name="telainicial" component={HomeScreen} />
//       <Stack.Screen name="Site" component={DrawerNav} />
//     </Stack.Navigator>
//   );
// }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  Retornar: {
    backgroundColor: "Gray",
    color: "black"
  },
});
