import {
  Text,
  Image,
  View,
  StyleSheet,
} from 'react-native';

export default function Comentario(props) {
  return (
    <View style={styles.card}>

      {/* Figurinha */}
      <View style={styles.figurinha}>

        <View style={styles.imageWrapper}>
          <Image
            style={styles.playerImage}
            source={props.image}
            resizeMode="cover"
          />
        </View>
      </View>

      {/* Texto lateral */}
      <View style={styles.info}>
        <Text style={styles.username}>{props.username}</Text>
        <Text style={styles.comment}>{props.comentario}</Text>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#505050',
    borderRadius: 15,
    padding: 14,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-start',
    borderWidth: 1.5,
    borderColor: '#ffffff',
    gap: 12,
  },

  /* ---- Figurinha ---- */
  figurinha: {
    width: 90,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#000000',
    backgroundColor: '#ffffff',
    flexShrink: 0,
  },

  figurinhaTop: {
    backgroundColor: '#ff0000',
    paddingVertical: 4,
    alignItems: 'center',
  },

  figurinhaPais: {
    fontSize: 9,
    fontWeight: 'bold',
    color: '#ff0000',
    letterSpacing: 1,
  },

  imageWrapper: {
    width: '100%',
    aspectRatio: 3 / 4,
    backgroundColor: '#ffffff',
  },

  playerImage: {
    width: '100%',
    height: '100%',
  },

  figurinhaBottom: {
    backgroundColor: '#555',
    paddingVertical: 5,
    paddingHorizontal: 6,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  figurinhaName: {
    fontSize: 8,
    fontWeight: 'bold',
    color: '#ffffff',
    flexShrink: 1,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },

  figurinhaNum: {
    fontSize: 10,
    color: '#ffffff',
    fontWeight: 'bold',
  },

  /* ---- Texto lateral ---- */
  info: {
    flex: 1,
    justifyContent: 'flex-start',
  },

  username: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 15,
    marginBottom: 6,
  },

  comment: {
    color: '#e8f5e9',
    fontSize: 13,
    lineHeight: 19,
  },
});