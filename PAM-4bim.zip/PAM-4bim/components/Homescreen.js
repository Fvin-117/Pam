import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
  Pressable,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Comentario from './comentario';

const assets = {
  retorno: require('../assets/retorno.png'),
  bulbasaur: require('../assets/bulbasaur.png'),
  charmander: require('../assets/charmander.png'),
  squirtle: require('../assets/squirtle.png'),
  chikorita: require('../assets/chikorita.png'),
  cyndaquil: require('../assets/cyndaquil.png'),
  totodile: require('../assets/totodile.png'),
};

const DATA = [
  {
    id: '1',
    username: 'Bulbasaur',
    comment: 'Primeiro pokémon inicial da região de Kanto',
    image: assets.bulbasaur
  },
  {
    id: '2',
    username: 'Charmander',
    comment: 'Segundo pokémon inicial da região de Kanto.',
    image: assets.charmander
  },
  {
    id: '3',
    username: 'Squirtle',
    comment: 'Terceiro pokémon inicial da região de Kanto.',
    image: assets.squirtle
  },
  {
    id: '4',
    username: 'Chikorita',
    comment: 'Primeiro pokémon inicial da região de Johto.',
    image: assets.chikorita
  },
  {
    id: '5',
    username: 'Cyndaquil',
    comment: 'Segundo pokémon inicial da região de Johto.',
    image: assets.cyndaquil
  },
  {
    id: '6',
    username: 'Totodile',
    comment: 'Terceiro pokémon inicial da região de Johto.',
    image: assets.totodile
  },
];

export default function HomeScreen() {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable
          style={styles.Retornar}
          onPress={() => navigation.navigate('telainicial')}
        >
          <Image style={styles.poke} source={assets.retorno} />
        </Pressable>
        <Text style={styles.paragraph}>Pokemons</Text>
      </View>
      <View style={styles.container1}>
        <FlatList
          data={DATA}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 10 }}
          renderItem={({ item }) => (
            <Comentario
              username={item.username}
              comentario={item.comment}
              image={item.image}
            />
          )}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f0d0',
  },
  container1: {
    flex: 1,
    backgroundColor: '#f5f0d0',
  },
  header: {
    backgroundColor: '#ff0000',
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 15,
  },
  paragraph: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  poke: {
    width: 25,
    height: 25,
    tintColor: '#ffffff',
  },
});