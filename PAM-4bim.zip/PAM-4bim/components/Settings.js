import React, { useState } from 'react';

import {
  Image,
  StyleSheet,
  Text,
  View,
  Pressable,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';

import { useNavigation } from '@react-navigation/native';

const assets = {
  retorno: require('../assets/retorno.png'),
};

export default function Contato() {
  const navigation = useNavigation();

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [mensagem, setMensagem] = useState('');

  const handleEnviar = () => {
    if (!nome || !email || !mensagem) {
      Alert.alert('Atenção', 'Por favor, preencha todos os campos.');
      return;
    }

    Alert.alert('Sucesso', 'Mensagem enviada com sucesso!');
    setNome('');
    setEmail('');
    setMensagem('');
  };

  return (
    <View style={styles.container}>

      {/* Header */}
      <View style={styles.header}>

        <Pressable
          style={styles.Retornar}
          onPress={() => {
            navigation.navigate('telainicial');
          }}
        >
          <Image
            style={styles.poke}
            source={assets.retorno}
          />
        </Pressable>

        <Text style={styles.headerTitle}>
          Contato
        </Text>

      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>

  

        {/* Card de informações */}
        <View style={styles.infoCard}>

          <Text style={styles.infoTitle}>
            Outras formas de contato
          </Text>

          <Text style={styles.infoText}>
            📧 Flavio Lacerda
            </Text>
          <Text style={styles.infoText}>
            📧 Fellipe Rafael
          </Text>

          <Text style={styles.infoText}>
            📞 (15) 99999-9999
          </Text>
          <Text style={styles.infoText}>
            📞 929-556-2746
          </Text>

          <Text style={styles.infoText}>
            📍 Sorocaba, Brasil
          </Text>

        </View>

      </ScrollView>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },

  header: {
    backgroundColor: '#ff0000',
    height: 50,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',

    paddingHorizontal: 15,
  },

  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },

  Retornar: {
    position: 'absolute',
    left: 15,
  },

  poke: {
    width: 25,
    height: 25,
  },

  scrollContent: {
    padding: 20,
  },

  contactCard: {
    backgroundColor: '#000000',

    borderRadius: 20,
    padding: 20,

    borderWidth: 3,
    borderColor: '#555',

    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,

    marginBottom: 20,
  },

  sectionTitle: {
    color: '#555',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },

  label: {
    color: '#555',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 6,
  },

  input: {
    backgroundColor: 'white',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ffffff',

    paddingHorizontal: 12,
    paddingVertical: 10,

    color: '#1a1a1a',
    fontSize: 15,

    marginBottom: 16,
  },

  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },

  botaoEnviar: {
    backgroundColor: '#7c7c7c',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
  },

  botaoEnviarTexto: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  infoCard: {
    backgroundColor: '#ff0000',
    borderRadius: 20,
    padding: 20,

    borderWidth: 2,
    borderColor: '#555555',
  },

  infoTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },

  infoText: {
    color: 'white',
    fontSize: 15,
    marginBottom: 8,
  },
});