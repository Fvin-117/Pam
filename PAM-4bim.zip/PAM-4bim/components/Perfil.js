import {
  ScrollView,
  Image,
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
} from 'react-native';

import { useState } from 'react';
import { useNavigation } from '@react-navigation/native';

export default function Perfil() {
  const navigation = useNavigation();
  const [username, setUsername] = useState('');
  const [descricao, setDescricao] = useState('');
  const [email, setEmail] = useState('');
  const [dataNasc, setDataNasc] = useState('');

  function limparCampos() {
    setUsername('');
    setDescricao('');
    setEmail('');
    setDataNasc('');
  }

  return (
    <ScrollView style={styles.container}>

      {/* Header */}
      <View style={styles.header}>
        <Pressable
          style={styles.Retornar}
          onPress={() => navigation.navigate('telainicial')}
        >
          <Image source={require('../assets/retorno.png')} style={styles.poke} />
        </Pressable>
        <Text style={styles.headerTitle}>Perfil</Text>
      </View>

      {/* Card Form */}
      <View style={styles.profileCard}>

        <Text style={styles.cardTitle}>Editar Perfil</Text>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Nome de usuário</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite seu usuário..."
            placeholderTextColor="#ffffff"
            value={username}
            onChangeText={setUsername}
          />
        </View>

        <View style={styles.inputBox}>
          <Text style={styles.label}>E-mail</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite seu e-mail..."
            placeholderTextColor="#ffffff"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
          />
        </View>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Data de nascimento</Text>
          <TextInput
            style={styles.input}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#ffffff"
            keyboardType="numeric"
            value={dataNasc}
            onChangeText={setDataNasc}
          />
        </View>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Descrição</Text>
          <TextInput
            style={[styles.input, styles.inputMultiline]}
            placeholder="Fale um pouco sobre você..."
            placeholderTextColor="#ffffff"
            multiline
            numberOfLines={4}
            value={descricao}
            onChangeText={setDescricao}
          />
        </View>

        <Pressable
          style={({ pressed }) => [styles.botao, pressed && styles.botaoPressed]}
          onPress={limparCampos}
        >
          <Text style={styles.botaoTexto}>✅ Enviar</Text>
        </Pressable>

      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },

  header: {
    backgroundColor: '#ff0000',
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 15,
  },

  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
  },

  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  poke: {
    width: 25,
    height: 25,
    tintColor: '#000000',
  },

  profileCard: {
    margin: 20,
    backgroundColor: '#464444',
    borderRadius: 25,
    padding: 25,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
    borderWidth: 2,
    borderColor: '#ffffff',
  },

  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
    textAlign: 'center',
  },

  inputBox: {
    width: '100%',
    marginBottom: 16,
  },

  label: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
  },

  input: {
    backgroundColor: '#ffffff',
    color: 'black',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    borderWidth: 1.5,
    borderColor: '#4e4e4e',
  },

  inputMultiline: {
    height: 100,
    textAlignVertical: 'top',
  },

  botao: {
    marginTop: 10,
    backgroundColor: '#817575',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },

  botaoPressed: {
    backgroundColor: '#ffffff',
    transform: [{ scale: 0.97 }],
  },

  botaoTexto: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});