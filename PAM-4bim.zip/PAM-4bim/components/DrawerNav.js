import { createDrawerNavigator } from '@react-navigation/drawer';
import Perfil from './Perfil';
import Pokedex from './Pokedex';
import BottomTabs from './BottomTabs';
import Settings from './Settings';

const Drawer = createDrawerNavigator();

export default function DrawerNav() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#ff0000',
        },
        headerTintColor: '#ffffff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        drawerStyle: {
          backgroundColor: '#000000',
        },
        drawerLabelStyle: {
          color: '#ffffff',
          fontWeight: 'bold',
          fontSize: 15,
        },
        drawerActiveTintColor: '#ff0000',
        drawerInactiveTintColor: '#a8d5b5',
        drawerActiveBackgroundColor: '#000000',
      }}
    >
      <Drawer.Screen name="Home" component={BottomTabs} />
      <Drawer.Screen name="Pokedex" component={Pokedex} />
      <Drawer.Screen name="Contatos" component={Settings} />
      <Drawer.Screen name="Form" component={Perfil} />
    </Drawer.Navigator>
  )
}