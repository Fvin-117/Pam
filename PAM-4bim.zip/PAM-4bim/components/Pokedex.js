import React, { useState } from 'react';

import { useNavigation } from '@react-navigation/native';
import DeckCard from './DeckCard';
import { Chip } from 'react-native-paper';

import {
  FlatList,
  StyleSheet,
  Text,
  View,
  Pressable,
  Image,
} from 'react-native';

const DATA = [
  {
    id: '1',
    title: 'Bulbasaur',
    type: 'Planta',
    description:
      ' Um pequeno Pokémon quadrúpede parecido com um dinossauro verde-azulado. Ele carrega uma semente nas costas desde o nascimento. Essa semente cresce absorvendo os raios solares.',
    color: '#00b118',
  },
  {
    id: '2',
    title: 'Charmander',
    type: 'Fogo',
    description:
      'Um pequeno lagarto bípede de pele alaranjada. A principal característica dele é a chama que brilha na ponta de sua cauda, que indica sua saúde e seu estado de ânimo.',
    color: '#db0000',
  },
  {
    id: '3',
    title: 'Squirtle',
    type: 'Água',
    description:
      'Uma pequena tartaruga bípede de cor azul. Ela se protege de ataques perigosos puxando seu corpo macio para dentro de sua carapaça rígida e cuspindo água com muita força.',
    color: '#0076d6',
  },
  {
    id: '4',
    title: 'Chikorita',
    type: 'Planta',
    description:
      'Um pequeno Pokémon quadrúpede de coloração verde-clara. Ele tem uma folha grande na cabeça que emite um aroma suave e relaxante, e usa essa folha para monitorar a temperatura e a umidade do ar.',
    color: '#00b118',
  },
  {
    id: '5',
    title: 'Cyndaquil',
    type: 'Fogo',
    description:
      'Um pequeno mamífero bípede que lembra uma equidna. Ele costuma ser tímido e se encolhe em formato de bola. Quando se assusta ou se irrita, chamas intensas irrompem de suas costas.',
    color: '#db0000',
  },
  {
    id: '6',
    title: 'Totodile',
    type: 'Água',
    description:
      'Um pequeno jacaré bípede de cor azul com mandíbulas extremamente fortes. Ele é muito enérgico e curioso, tendo o péssimo hábito de morder qualquer coisa que se mova perto dele.',
    color: '#0076d6',
  },
];

export default function Pokedex() {
  const navigation = useNavigation();
  const [activeFilter, setActiveFilter] = useState('all');

  const filters = {
    all: 'Todos',
    planta: 'Tipo planta 🍃',
    fogo: 'Tipo fogo 🔥',
    água: 'Tipo água 💧',
  };

  const chipColors = {
    all: '#fff',
    planta: '#00b118',
    fogo: '#db0000',
    água: '#0076d6',
  };

  const filteredData = activeFilter === 'all'
    ? DATA
    : DATA.filter((item) => item.type.toLowerCase() === activeFilter);

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <Pressable
          style={styles.Retornar}
          onPress={() => navigation.navigate('telainicial')}
        >
          <Image style={styles.poke} source={require('../assets/retorno.png')} />
        </Pressable>
        <Text style={styles.pageTitle}>Pokedex</Text>
      </View>

      <View style={styles.chipsContainer}>
        {Object.entries(filters).map(([filter, label]) => (
          <Chip
            key={filter}
            selected={activeFilter === filter}
            onPress={() => setActiveFilter(filter)}
            style={[
              styles.chip,
              { backgroundColor: chipColors[filter] },
            ]}
            textStyle={{ color: filter === 'all' ? '#000000' : '#ffffff' }}
          >
            {label}
          </Chip>
        ))}
      </View>

      <FlatList
        data={filteredData}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 15 }}
        renderItem={({ item }) => (
          <DeckCard
            title={item.title}
            description={item.description}
            color={item.color}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d3d3d3',
  },

  topBar: {
    height: 50,
    backgroundColor: '#ff0101',
    justifyContent: 'center',
    alignItems: 'center',
  },

  pageTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  chipsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    paddingHorizontal: 15,
    paddingTop: 12,
    paddingBottom: 4,
    backgroundColor: '#d3d3d3',
  },

  chip: {
    marginBottom: 4,
  },
  card: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 15,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },

  title: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    width: '75%',
  },

  description: {
    color: 'white',
    fontSize: 15,
    lineHeight: 22,
  },
  poke: {
    width: 25,
    height: 25,
  },
  Retornar: {
    position: 'absolute',
    left: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
});